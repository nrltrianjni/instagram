

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AE</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/logo.jpeg">
</head>
<body>
    <div class="container">
    <form action="proses_login.php" method="post">
        <div align="center">
            <img src="img/logo.jpeg" width="90" height="90" alt="">
        </div><br>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="off" required placeholder=" Enter Username">

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required placeholder="Enter Password">

        <button input type="submit" value="Sign In">Sign In</button>
    </form>
</div>
</body>
</html>