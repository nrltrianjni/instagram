<?php

include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="img/logo.jpeg">
    <title>Instagram</title>
    <style>

/* img {
   width: 60px;
   height: 60px;
   border-radius: 50%;
} */



.zoom {
  transition: transform .2s; /* Animation */
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
</head>
<body>
<nav class="navbar sticky-top navbar-expand-lg " style="background-color:black;">
  <div class="container-fluid">
    <a class="text-light navbar-brand" href="#" >
   
    <img src="img/logo.jpeg" heigh="55" width="60" class="img-circle"><br>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <div a class="text-light nav-link active" aria-current="page" href="#">Postingan</a></div>
        </li>
        </li>
      </ul>
      <div align="right">
      <a href="tambah.php" class="btn btn-primary"><i class="fa fa-plus"></i></a>
        <a href="logout.php" class="btn btn-danger"><i class="fa fa-arrow-right-from-bracket"></i></a>
</div>
    </div>
  </div>
</nav><br><br>
<div align="center" class="container">
  <?php while ($post = mysqli_fetch_assoc($query)) { ?>

  <center>      
     <div class="card d-inline-block" style="width: 18rem;">
     <div class="zoom">
     <img src="img/<?= $post['foto'] ?>" alt=""  class="card-img-top" width="100" >
  </div>
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text"><?= $post['caption']?></p>
    <h5 class="card-title"></h5>
    <p class="card-text"><?= $post['lokasi']?></p>
    <a href="edit.php?no=<?= $post['no'] ?>"><button class="btn btn-secondary"><i class="fa-solid fa-pencil"></i></button></a>
    <a href="hapus.php?no=<?= $post['no'] ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></a>
  </div>
</div>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
     <?php } ?>
 </table>
 </body>
 </html>